//
//  Alderis.h
//  Alderis
//
//  Created by Adam Demasi on 16/3/20.
//  Copyright © 2020 HASHBANG Productions. All rights reserved.
//

@import UIKit;

#import "AlderisSDKCompatibility.h"
